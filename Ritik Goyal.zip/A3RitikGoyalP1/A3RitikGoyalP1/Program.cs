﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A3RitikGoyalP1
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine(" enter 1 for a list of even numbers starting from 0 ");
                Console.WriteLine(" enter 2 for display a sequence of perfect squares starting from 1 ");
                Console.WriteLine(" enter 3 to exit ");
                double main = double.Parse(Console.ReadLine());

                if (main == 1)
                {
                    Console.WriteLine(" Type the number of even numbers you want as result ");
                    double even = double.Parse(Console.ReadLine());

                    for (int e = 2; e < 2 * even; e = e + 2)
                    {
                        Console.WriteLine(e);
                    }

                }



                if (main == 2)
                {
                    Console.WriteLine("1");
                    do
                    {

                        Console.WriteLine(" Enter 1 to continue and 2 to stop ");
                        char abc = char.Parse(Console.ReadLine());

                    } while (Console.ReadLine() != "1");
                    {
                        int dq = 1;
                        int f = (dq + 1) * (dq + 1);
                        Console.WriteLine(f);

                    }
                }

                if (main == 3)
                {



                }



            }
            catch (FormatException z)
            {
                Console.WriteLine("Type valid value");

            }

            finally
            {

            }

        }
    }
}
